public class Main {
    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.add_puertas();
        System.out.println(miCoche.puertas);
    }
}
class Coche {
    public int puertas = 4;
    public void add_puertas(){
        this.puertas++;
    }
}