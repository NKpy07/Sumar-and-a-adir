public class Main {
    public static void main(String[] args) {
        int numero1 = 2; int numero2 = 3; int numero3 = 5;
        int resultado = suma(numero1, numero2, numero3);
        System.out.println(resultado);
    }
    public static int suma(int num1, int num2, int num3) {
        return num1 + num2 + num3;
    }
}